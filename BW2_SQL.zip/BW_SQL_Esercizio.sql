/* 1. Marca e Colore delle Auto di che costano più di 10.000 € */
SELECT Marca, Colore
FROM Auto
WHERE Prezzo > 10000;


/* 2. Tutti i proprietari di un’auto di colore ROSSO */
SELECT p.nominativo, a.colore
FROM proprietari AS p
JOIN auto AS a ON p.id_auto = a.id
WHERE a.colore = 'rosso'
ORDER BY p.nominativo ASC;


/* 3. Costo totale di tutte le auto con Cilindrata superiore a 1600 */
SELECT SUM(Prezzo) AS CostoTotale
FROM Auto
WHERE Cilindrata > 1600;


/* 4. Targa e Nome del proprietario delle Auto in una concessionaria della Città di Roma */
SELECT a.targa, p.nominativo AS Proprietario
FROM auto AS a
JOIN proprietari AS p ON p.id_auto = a.id
JOIN concessionaria AS c ON c.id = a.id_concessionaria
WHERE c.citta = 'roma';

/* 5. Per ogni Concessionaria, il numero di Auto */
SELECT COUNT(a.id) AS Num_Auto, c.citta AS Citta
FROM auto AS a
JOIN concessionaria AS c ON c.id = a.id_concessionaria
GROUP BY Citta;


/* 6. Il Responsabile di Concessionaria di tutte le auto con Cambio Automatico e Anno Acquisto 2010 */
SELECT a.id, c.responsabile AS Nome, a.tipocambio AS Cambio, p.annoacquisto AS anno
FROM concessionaria AS c
JOIN auto AS a ON c.id = a.id_concessionaria
JOIN proprietari AS p ON p.id_auto = a.id
WHERE p.annoacquisto = '2010'
AND a.tipocambio = 'Automatico';


/*  7. Per ciascuna TARGA il colore, il prezzo e la città in cui si trova il veicolo */
SELECT a.Targa, a.Colore, a.Prezzo, c.Citta
FROM Auto a
JOIN Concessionaria c ON a.ID_Concessionaria = c.ID;


/*  8. Le auto con almeno tre Proprietari */
SELECT a.id AS auto, COUNT(p.nominativo) AS Proprietario
FROM Auto a
JOIN proprietari AS p ON a.id = p.ID_Auto
GROUP BY Auto HAVING Proprietario >= 3


/*  9. La targa delle auto vendute nel 2015 */
SELECT a.targa AS Targa, p.annoacquisto AS Anno
FROM Auto a
JOIN proprietari AS p ON a.id = p.ID_Auto
WHERE p.annoacquisto = '2015'


/* 10. La regione con più auto (trovare un modo per associare la Regione) */
SELECT c.regione, COUNT(a.id) as AUTO
FROM concessionaria AS c
JOIN auto AS a ON a.ID_Concessionaria = c.ID
GROUP BY c.regione
ORDER BY auto DESC LIMIT 1;


/* 11. La Targa delle auto che si trovano a Milano, con cambio automatico, colore rosso, di
proprietari residenti a Milano  */
SELECT a. id, a.targa AS Targa
FROM auto  AS a
JOIN proprietari AS p ON a.id = p.ID_Auto
JOIN concessionaria AS c ON a.ID_Concessionaria = c.ID
WHERE c.citta = 'milano'
AND a.tipocambio = 'automatico'
AND a.colore = 'rosso'
AND p.cittaresidenza = 'milano';





/*  REPORTISTICA AZIENDALE PER ESTRAZIONE EXCEL  */
/*  Gestione del fatturato  */
SELECT c.ID AS ID_Concessionaria, c.Responsabile AS Manager, c.Citta, c.Regione, SUM(a.Prezzo) AS Fatturato
FROM Concessionaria c
JOIN Auto a ON c.ID = a.ID_Concessionaria
GROUP BY c.ID, c.Citta, c.Regione
ORDER BY Fatturato DESC;


/*  Gestione Clienti per Concessionaria  */
SELECT c.ID AS ID_Concessionaria, c.Citta, c.Regione, p.Nominativo
FROM Concessionaria c
JOIN Auto a ON c.ID = a.ID_Concessionaria
JOIN Proprietari p ON a.ID = p.ID_Auto
ORDER BY c.ID, p.Nominativo;


/*  Quanti clienti ci sono per concessionaria */
SELECT c.ID AS ID_Concessionaria, c.Citta, c.Regione, COUNT(p.Nominativo) AS NumeroClienti
FROM Concessionaria c
JOIN Auto a ON c.ID = a.ID_Concessionaria
JOIN Proprietari p ON a.ID = p.ID_Auto
GROUP BY c.ID, c.Citta, c.Regione
ORDER BY NumeroClienti DESC;


/*  Quali brand sono i più venduti  */
SELECT a.Marca, COUNT(p.annoacquisto) AS Vendute, SUM(a.prezzo) AS Fatturato
FROM Auto AS a
JOIN Concessionaria AS c ON c.ID = a.ID_Concessionaria
JOIN Proprietari AS p ON a.ID = p.ID_Auto
WHERE p.annoacquisto IS NOT NULL
GROUP BY Marca
ORDER BY Vendute DESC;


/*  Quali colori sono i più richiesti  */
SELECT Colore, COUNT(*) AS Quantita
FROM Auto AS a
JOIN Concessionaria AS c ON c.ID = a.ID_Concessionaria
JOIN Proprietari AS p ON a.ID = p.ID_Auto
WHERE p.annoacquisto IS NOT NULL
GROUP BY Colore
ORDER BY Quantita DESC;


/*  Fattutato per città e anno */
SELECT c.ID AS ID_Concessionaria, c.Citta, c.Regione, p.AnnoAcquisto AS Anno, SUM(a.Prezzo) AS Fatturato
FROM Concessionaria c
JOIN Auto a ON c.ID = a.ID_Concessionaria
JOIN Proprietari p ON a.ID = p.ID_Auto
WHERE p.AnnoAcquisto IS NOT NULL
GROUP BY c.ID, c.Citta, c.Regione, Anno
ORDER BY Anno, Fatturato DESC;