
/*ToysGroup è un’azienda che distribuisce articoli (giocatoli) in diverse aree geografiche del mondo. 
I prodotti sono classificati in categorie e i mercati di riferimento dell’azienda sono classificati 
in regioni di vendita.
In particolare: 
Le entità individuabili in questo scenario sono le seguenti: - Product - Region - Sales.  
Le relazioni tra le entità possono essere descritte nel modo seguente: 
Product e Sales: Un prodotto può essere venduto tante volte (o nessuna) per cui è contenuto in una o più transazioni di vendita. 
Ciascuna transazione di vendita è riferita ad uno solo prodotto 
Region e Sales: Possono esserci molte o nessuna transazione per ciascuna regione 
Ciascuna transazione di vendita è riferita ad una sola regione.  
Fornisci schema concettuale e schema logico. */

/* 
Schema Concettuale
TABELLA PRODUCT
IdProduct INT PK NOT NULL
ProductName VARCHAR(45) NOT NULL
Category VARCHAR (45) NOT NULL
UnitPrice DECIMAL (10,2) NOT NULL
Description VARCHAR (100)

TABELLA REGION
IdRegion INT PK NOT NULL
RegionName VARCHAR (45) NOT NULL
Country VARCHAR (45) NOT NULL

TABELLA SALE
IdSale INT PK NOT NULL
IdProduct INT FK NOT NULL
IdRegion INT FK NOT NULL
QuantitySold INT NOT NULL
SaleDate INT NOT NULL
Amount DECIMAL (10,2) NOT NULL

Relazioni:
Product - Sale: (1:N).

Region - Sale: (1:N).
*/

-- Schema Logico
-- Creazione del Databse e settaggio dello stesso come Default

CREATE SCHEMA `ToysGroup` ;
USE `ToysGroup`;

-- Creazione della tabella Product
CREATE TABLE Product (
    IdProduct INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(45) NOT NULL,
    Category VARCHAR(45) NOT NULL,
    UnitPrice DECIMAL(10 , 2 ) NOT NULL,
    Description VARCHAR(100)
);
-- Creazione della tabella Region
CREATE TABLE Region (
    IdRegion INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    RegionName VARCHAR(45) NOT NULL,
    Country VARCHAR(45)
);
-- Creazione della tabella Sales e individuazioni delle chiavi esterne
CREATE TABLE Sale (
    IdSale INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    IdProduct INT NOT NULL,
    IdRegion INT NOT NULL,
    QuantitySold INT NOT NULL,
    SaleDate DATE NOT NULL,
    FOREIGN KEY (IdProduct)
        REFERENCES Product (IdProduct),
    FOREIGN KEY (IdRegion)
        REFERENCES Region (IdRegion)
);
ALTER TABLE `toysgroup`.`sale` 
ADD COLUMN `Amount` DECIMAL(10,2) NOT NULL AFTER `SaleDate`;

ALTER TABLE `toysgroup`.`sale` 
DROP FOREIGN KEY `sale_ibfk_1`;
ALTER TABLE `toysgroup`.`sale` 
CHANGE COLUMN `QuantitySold` `QuantitySold` INT NULL ;
ALTER TABLE `toysgroup`.`sale` 
ADD CONSTRAINT `sale_ibfk_1`
  FOREIGN KEY (`IdProduct`)
  REFERENCES `toysgroup`.`product` (`IdProduct`)
  ON DELETE CASCADE
  ON UPDATE CASCADE;


-- Popolamento Tabella "Product"
INSERT INTO Product (IdProduct, ProductName, Category, UnitPrice, Description)
VALUES
    (1, 'Macchina da corsa telecomandata', 'Giocattoli', 29.99, 'Unauto telecomandata per bambini di tutte le età'),
    (2, 'Bambola Barbie', 'Bambole', 19.99, 'La bambola più famosa del mondo'),
    (3, 'Lego City Stazione di Polizia', 'Costruzioni', 49.99, 'Un set di costruzioni per bambini dai 6 anni in su'),
    (4, 'Palloncino a forma di animale', 'Feste & Compleanni', 3.99, 'Palloncini perfetti per feste di compleanno e altre occasioni'),
    (5, 'Gioco da tavolo Monopoly', 'Giochi da Tavolo', 24.99, 'Un classico gioco da tavolo per tutta la famiglia'),
    (6, 'Puzzle 1000 pezzi', 'Giochi & Puzzle', 14.99, 'Un puzzle per mettere alla prova le tue capacità'),
    (7, 'Peluche orsetto', 'Peluche', 12.99, 'Un morbido orsetto per bambini di tutte le età'),
    (8, 'Libro da colorare', 'Libri', 9.99, 'Un libro da colorare per bambini dai 3 anni in su'),
    (9, 'Set di matite colorate', 'Belle Arti', 5.99, 'Un set di matite colorate per dare sfogo alla tua creatività'),
    (10, 'Gioco di carte UNO', 'Giochi di Carte', 5.99, 'Un gioco di carte divertente per tutta la famiglia'),
    (11, 'Action figure supereroe', 'Giocattoli', 19.99, 'Unaction figure del tuo supereroe preferito'),
    (12, 'Pista Hot Wheels', 'Giocattoli', 24.99, 'Una pista per far correre le tue macchinine'),
    (13, 'Gioco di società Indizio', 'Giochi da Tavolo', 17.99, 'Un gioco di società per risolvere un mistero'),
    (14, 'Tenda per bambini', 'Giochi per Bambini', 19.99, 'Una tenda per giocare in casa o in giardino'),
    (15, 'Piscina gonfiabile', 'Giochi per Bambini', 29.99, 'Una piscina gonfiabile per rinfrescarsi durante lestate'
);

-- Popolamento Tabella "Region"
INSERT INTO Region (IdRegion, RegionName, Country)
VALUES
    (1, 'Europa Occidentale', 'Italia'),
    (2, 'Europa Orientale', 'Polonia'),
    (3, 'Nord America', 'Stati Uniti'),
    (4, 'Sud America', 'Brasile'),
    (5, 'Asia', 'Cina'),
    (6, 'Africa', 'Sudafrica'),
    (7, 'Oceania', 'Australia')
;

-- Popolamento della tabella Sales
INSERT INTO Sale (IdProduct, IdRegion, QuantitySold, SaleDate, Amount) VALUES
(1, 1, 10, '2023-01-15', 150.00),
(2, 2, 5, '2023-02-28', 75.00),
(3, 3, 8, '2023-03-12', 200.00),
(4, 4, 3, '2023-04-05', 45.00),
(5, 5, 7, '2023-05-20', 140.00),
(6, 1, 4, '2023-06-08', 80.00),
(7, 2, 6, '2023-07-14', 180.00),
(8, 3, 2, '2023-08-25', 30.00),
(9, 4, 9, '2023-09-30', 270.00),
(10, 5, 11, '2023-10-10', 330.00),
(11, 1, 13, '2023-11-15', 390.00),
(12, 2, 15, '2023-12-25', 450.00),
(13, 3, 17, '2024-01-18', 510.00),
(14, 4, 19, '2024-02-25', 570.00),
(15, 5, 21, '2024-03-30', 630.00);


-- 1. Verificare che i campi definiti come PK siano univoci.  
SELECT 
    IdProduct, COUNT(*) AS Conta
FROM
    Product
GROUP BY IdProduct
HAVING COUNT(*) > 1;

SELECT 
    IdRegion, COUNT(*) AS Conta
FROM
    Region
GROUP BY IdRegion
HAVING COUNT(*) > 1;

SELECT 
    IdSale, COUNT(*) AS Conta
FROM
    Sale
GROUP BY IdSale
HAVING COUNT(*) > 1;
-- Considerando che queste query non restituiscono risultati, possiamo dedurre che i campi definiti come PK sono univoci

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  
SELECT 
    p.ProductName AS NomeProdotto,
    YEAR(s.SaleDate) AS Anno,
    SUM(s.Amount) AS FatturatoTotaleAnno
FROM
    Sale s
        JOIN
    Product p ON s.IdProduct = p.IdProduct
GROUP BY p.ProductName , YEAR(s.SaleDate);

-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT 
    r.RegionName AS NomeRegione,
    YEAR(s.SaleDate) AS Anno,
    SUM(s.Amount) AS FatturatoTotaleAnno
FROM
    Sale s
        JOIN
    Region r ON s.IdRegion = r.IdRegion
GROUP BY r.RegionName , YEAR(s.SaleDate)
ORDER BY YEAR(s.SaleDate) DESC, FatturatoTotaleAnno DESC;

-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
SELECT p.Category AS Categoria, SUM(s.QuantitySold) AS QuantitaVenduta
FROM Sale s
JOIN Product p ON s.IdProduct = p.IdProduct
GROUP BY p.Category
ORDER BY QuantitaVenduta DESC
LIMIT 1; -- il limite è stato settato a 1 cosicchè si mostra solo una categoria (quella maggiormente richiesta dal mercato)

-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
-- Approccio 1 -> Subquery
SELECT 
    p.ProductName AS NomeProdotto
FROM
    Product p
WHERE
    p.IdProduct NOT IN (SELECT DISTINCT
            IdProduct
        FROM
            Sale);
-- Utilizzo una sub query per verificare le quantità invendute. Questa evidenzia che tutti i prodotti sono stati venduti.

-- Approccio 2 Left Join
SELECT 
    p.ProductName AS NomeProdotto
FROM
    Product p
        LEFT JOIN
    Sale s ON p.IdProduct = s.IdProduct
WHERE
    s.IdProduct IS NULL;
/* Utilizzo una LEFT JOIN: includo tutti i record della tabella di sinistra, indipendentemente dal fatto che vi sia una corrispondenza
nella tabella di destra. Se ci fossero stati record senza corrispondenza nella tabella di destra, i campi sarebbero stati riempiti 
con valori NULL. Ma anche questo approccio evidenzia come non ci sono quantità invendute. */

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT 
    p.ProductName, MAX(s.SaleDate) AS UltimaDataVendita
FROM
    Sale s
        JOIN
    Product p ON s.IdProduct = p.IdProduct
GROUP BY p.ProductName;